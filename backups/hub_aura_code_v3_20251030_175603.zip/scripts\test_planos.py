"""Teste rápido para visualizar planos de trabalho gerados"""
import requests

# Buscar exemplos
response = requests.get('http://127.0.0.1:8001/api/v1/parcerias/busca?termo=educacao&limit=3')
data = response.json()

print("=" * 80)
print("EXEMPLOS DE PLANOS DE TRABALHO GERADOS")
print("=" * 80)
print()

for i, p in enumerate(data['items'], 1):
    print(f"📋 EXEMPLO {i}")
    print(f"   ID: {p['id']}")
    print(f"   Razão Social: {p['razao_social']}")
    print(f"   Objeto: {p['objeto'][:100]}...")
    print()
    print(f"   📄 PLANO DE TRABALHO:")
    print(f"   {p['plano_de_trabalho']}")
    print()
    print("-" * 80)
    print()
